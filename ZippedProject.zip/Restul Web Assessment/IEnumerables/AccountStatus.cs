﻿namespace Restul_Web_Assessment.IEnumerables
{
    public enum AccountStatus
    {
        Active,
        Inactive,
    }
}
